# Modello Scommesse – Streamlit

App Streamlit per analisi avanzata di scommesse calcistiche con modello Dixon-Coles Bayesiano.
Le quote vengono inserite manualmente per massima flessibilità e controllo.

## Segreti da configurare su Streamlit Cloud

Nel menu "Settings" → "Secrets" aggiungi (opzionali):

```toml
API_FOOTBALL_KEY = "la_tua_key_di_api_football"
